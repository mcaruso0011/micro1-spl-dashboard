import { useState, useEffect, useRef } from "react";

// ============================================================
// micro1 SPL Data Operations Dashboard
// A working demo showing how a Strategic Projects Lead
// would monitor expert performance, quality metrics,
// and pipeline health for AI training data projects
// ============================================================

// --- Simulated Data ---
const EXPERTS = [
  { id: "E-001", name: "Dr. Sarah Chen", domain: "Mathematics", university: "Stanford", rating: 4.9, tasksCompleted: 347, avgTime: 22, accuracy: 97.3, status: "active", trend: "up" },
  { id: "E-002", name: "Prof. James Okafor", domain: "Physics", university: "MIT", rating: 4.8, tasksCompleted: 289, avgTime: 26, accuracy: 95.1, status: "active", trend: "stable" },
  { id: "E-003", name: "Dr. Priya Sharma", domain: "Medicine", university: "Johns Hopkins", rating: 4.7, tasksCompleted: 412, avgTime: 19, accuracy: 98.2, status: "active", trend: "up" },
  { id: "E-004", name: "Dr. Alex Rivera", domain: "CS / ML", university: "Berkeley", rating: 4.6, tasksCompleted: 198, avgTime: 31, accuracy: 93.8, status: "review", trend: "down" },
  { id: "E-005", name: "Prof. Elena Volkov", domain: "Linguistics", university: "Oxford", rating: 4.9, tasksCompleted: 503, avgTime: 17, accuracy: 99.1, status: "active", trend: "up" },
  { id: "E-006", name: "Dr. Marcus Kim", domain: "Law", university: "Harvard", rating: 4.5, tasksCompleted: 156, avgTime: 35, accuracy: 91.4, status: "review", trend: "down" },
  { id: "E-007", name: "Dr. Fatima Al-Hassan", domain: "Chemistry", university: "Caltech", rating: 4.8, tasksCompleted: 267, avgTime: 24, accuracy: 96.7, status: "active", trend: "stable" },
  { id: "E-008", name: "Prof. David Tanaka", domain: "Economics", university: "Princeton", rating: 4.7, tasksCompleted: 321, avgTime: 28, accuracy: 94.5, status: "active", trend: "up" },
];

const PIPELINE_STAGES = [
  { name: "Ingestion", tasks: 1247, completed: 1198, errors: 12, throughput: 96.1 },
  { name: "Annotation", tasks: 1198, completed: 987, errors: 34, throughput: 82.4 },
  { name: "QA Review", tasks: 987, completed: 891, errors: 8, throughput: 90.3 },
  { name: "Rhea AI QC", tasks: 891, completed: 867, errors: 3, throughput: 97.3 },
  { name: "Client Delivery", tasks: 867, completed: 852, errors: 0, throughput: 98.3 },
];

const DAILY_METRICS = [
  { day: "Mon", tasks: 189, quality: 96.2, velocity: 23 },
  { day: "Tue", tasks: 214, quality: 95.8, velocity: 21 },
  { day: "Wed", tasks: 198, quality: 97.1, velocity: 22 },
  { day: "Thu", tasks: 231, quality: 94.3, velocity: 25 },
  { day: "Fri", tasks: 207, quality: 96.9, velocity: 20 },
  { day: "Sat", tasks: 142, quality: 97.8, velocity: 18 },
  { day: "Sun", tasks: 118, quality: 98.1, velocity: 17 },
];

const ALERTS = [
  { type: "warning", message: "Dr. Rivera's accuracy dropped below 94% threshold — recommend paired review", time: "12 min ago" },
  { type: "info", message: "Annotation stage throughput recovered to 82.4% after overnight backlog clear", time: "1 hr ago" },
  { type: "success", message: "Prof. Volkov hit 500-task milestone with 99.1% accuracy — bonus eligible", time: "2 hrs ago" },
  { type: "warning", message: "Dr. Kim flagged for extended task times (35 min avg vs 25 min target)", time: "3 hrs ago" },
  { type: "info", message: "Client Lab Alpha requested scope expansion: +200 physics tasks this sprint", time: "5 hrs ago" },
];

// --- Utility Components ---
const StatusDot = ({ status }) => {
  const colors = { active: "#22c55e", review: "#f59e0b", inactive: "#94a3b8" };
  return (
    <span style={{
      display: "inline-block", width: 8, height: 8, borderRadius: "50%",
      backgroundColor: colors[status] || "#94a3b8", marginRight: 6,
      boxShadow: status === "active" ? "0 0 6px #22c55e55" : "none",
    }} />
  );
};

const TrendArrow = ({ trend }) => {
  if (trend === "up") return <span style={{ color: "#22c55e", fontSize: 14, fontWeight: 700 }}>↑</span>;
  if (trend === "down") return <span style={{ color: "#ef4444", fontSize: 14, fontWeight: 700 }}>↓</span>;
  return <span style={{ color: "#94a3b8", fontSize: 14 }}>→</span>;
};

const AlertIcon = ({ type }) => {
  const icons = { warning: "⚠", info: "ℹ", success: "✓" };
  const colors = { warning: "#f59e0b", info: "#60a5fa", success: "#22c55e" };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      width: 24, height: 24, borderRadius: 6, fontSize: 12, fontWeight: 700,
      backgroundColor: colors[type] + "18", color: colors[type], flexShrink: 0,
    }}>{icons[type]}</span>
  );
};

// --- Mini Bar Chart ---
const MiniBar = ({ data, dataKey, color, height = 80 }) => {
  const max = Math.max(...data.map(d => d[dataKey]));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height, padding: "0 2px" }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
          <div style={{
            width: "100%", maxWidth: 28, borderRadius: 4,
            height: `${(d[dataKey] / max) * 100}%`, minHeight: 4,
            backgroundColor: color, opacity: 0.85,
            transition: "height 0.5s ease",
          }} />
          <span style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.02em" }}>{d.day}</span>
        </div>
      ))}
    </div>
  );
};

// --- Pipeline Funnel ---
const PipelineFunnel = ({ stages }) => {
  const maxTasks = stages[0].tasks;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {stages.map((stage, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ width: 100, fontSize: 12, color: "#94a3b8", textAlign: "right", fontFamily: "'JetBrains Mono', monospace" }}>
            {stage.name}
          </span>
          <div style={{ flex: 1, height: 28, backgroundColor: "#1e293b", borderRadius: 6, overflow: "hidden", position: "relative" }}>
            <div style={{
              height: "100%", borderRadius: 6,
              width: `${(stage.completed / maxTasks) * 100}%`,
              background: stage.errors > 10
                ? "linear-gradient(90deg, #f59e0b, #f97316)"
                : `linear-gradient(90deg, #0ea5e9, #6366f1)`,
              transition: "width 0.8s ease",
              display: "flex", alignItems: "center", paddingLeft: 10,
            }}>
              <span style={{ fontSize: 11, color: "#fff", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace" }}>
                {stage.completed.toLocaleString()}
              </span>
            </div>
            {stage.errors > 0 && (
              <span style={{
                position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
                fontSize: 10, color: stage.errors > 10 ? "#f59e0b" : "#64748b",
                fontFamily: "'JetBrains Mono', monospace",
              }}>
                {stage.errors} err
              </span>
            )}
          </div>
          <span style={{
            width: 48, fontSize: 12, fontWeight: 600, textAlign: "right",
            color: stage.throughput >= 95 ? "#22c55e" : stage.throughput >= 85 ? "#f59e0b" : "#ef4444",
            fontFamily: "'JetBrains Mono', monospace",
          }}>
            {stage.throughput}%
          </span>
        </div>
      ))}
    </div>
  );
};

// --- Main Dashboard ---
export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedExpert, setSelectedExpert] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentTime, setCurrentTime] = useState(new Date());
  const [animateIn, setAnimateIn] = useState(false);

  useEffect(() => {
    setAnimateIn(true);
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const filteredExperts = EXPERTS.filter(e =>
    e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.domain.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalTasks = EXPERTS.reduce((a, e) => a + e.tasksCompleted, 0);
  const avgAccuracy = (EXPERTS.reduce((a, e) => a + e.accuracy, 0) / EXPERTS.length).toFixed(1);
  const avgTime = Math.round(EXPERTS.reduce((a, e) => a + e.avgTime, 0) / EXPERTS.length);
  const activeExperts = EXPERTS.filter(e => e.status === "active").length;

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "experts", label: "Expert Roster" },
    { id: "pipeline", label: "Pipeline" },
    { id: "alerts", label: `Alerts (${ALERTS.length})` },
  ];

  return (
    <div style={{
      minHeight: "100vh", backgroundColor: "#0b0f1a",
      fontFamily: "'DM Sans', -apple-system, sans-serif",
      color: "#e2e8f0",
      opacity: animateIn ? 1 : 0,
      transition: "opacity 0.6s ease",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=JetBrains+Mono:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
      `}</style>

      {/* Header */}
      <header style={{
        padding: "16px 28px", borderBottom: "1px solid #1e293b",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        background: "linear-gradient(180deg, #0f172a 0%, #0b0f1a 100%)",
        position: "sticky", top: 0, zIndex: 100,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: "linear-gradient(135deg, #0ea5e9, #6366f1)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, fontWeight: 700, color: "#fff", letterSpacing: "-0.02em",
          }}>m1</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: "-0.01em" }}>
              Data Ops Dashboard
            </div>
            <div style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
              Project: Lab Alpha — RLHF Sprint 14
            </div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <span style={{ fontSize: 12, color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>
            {currentTime.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
            {" · "}
            {currentTime.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
          </span>
          <div style={{
            width: 32, height: 32, borderRadius: "50%",
            background: "linear-gradient(135deg, #f59e0b, #ef4444)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 12, fontWeight: 700, color: "#fff",
          }}>MK</div>
        </div>
      </header>

      {/* Tabs */}
      <nav style={{
        display: "flex", gap: 0, padding: "0 28px",
        borderBottom: "1px solid #1e293b", background: "#0b0f1a",
        position: "sticky", top: 65, zIndex: 99,
      }}>
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
            padding: "12px 20px", fontSize: 13, fontWeight: activeTab === tab.id ? 600 : 400,
            color: activeTab === tab.id ? "#e2e8f0" : "#64748b",
            background: "none", border: "none", cursor: "pointer",
            borderBottom: activeTab === tab.id ? "2px solid #6366f1" : "2px solid transparent",
            transition: "all 0.2s ease", fontFamily: "inherit",
          }}>
            {tab.label}
          </button>
        ))}
      </nav>

      <main style={{ padding: 28, maxWidth: 1200, margin: "0 auto" }}>

        {/* ===== OVERVIEW TAB ===== */}
        {activeTab === "overview" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>

            {/* KPI Cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
              {[
                { label: "Total Tasks", value: totalTasks.toLocaleString(), sub: "this sprint", accent: "#0ea5e9" },
                { label: "Avg Accuracy", value: `${avgAccuracy}%`, sub: "across all experts", accent: "#22c55e" },
                { label: "Avg Task Time", value: `${avgTime} min`, sub: "target: 25 min", accent: avgTime <= 25 ? "#22c55e" : "#f59e0b" },
                { label: "Active Experts", value: `${activeExperts}/${EXPERTS.length}`, sub: `${EXPERTS.length - activeExperts} in review`, accent: "#6366f1" },
              ].map((kpi, i) => (
                <div key={i} style={{
                  background: "#111827", borderRadius: 12, padding: "20px 22px",
                  border: "1px solid #1e293b",
                  display: "flex", flexDirection: "column", gap: 6,
                }}>
                  <span style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.06em", fontWeight: 500 }}>
                    {kpi.label}
                  </span>
                  <span style={{ fontSize: 28, fontWeight: 700, color: kpi.accent, letterSpacing: "-0.02em", fontFamily: "'JetBrains Mono', monospace" }}>
                    {kpi.value}
                  </span>
                  <span style={{ fontSize: 11, color: "#475569" }}>{kpi.sub}</span>
                </div>
              ))}
            </div>

            {/* Charts Row */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={{ background: "#111827", borderRadius: 12, padding: 22, border: "1px solid #1e293b" }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 16 }}>Daily Task Volume</div>
                <MiniBar data={DAILY_METRICS} dataKey="tasks" color="#6366f1" height={100} />
              </div>
              <div style={{ background: "#111827", borderRadius: 12, padding: 22, border: "1px solid #1e293b" }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 16 }}>Daily Quality Score</div>
                <MiniBar data={DAILY_METRICS} dataKey="quality" color="#22c55e" height={100} />
              </div>
            </div>

            {/* Pipeline Quick View */}
            <div style={{ background: "#111827", borderRadius: 12, padding: 22, border: "1px solid #1e293b" }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                Pipeline Health
                <span style={{
                  fontSize: 11, color: "#22c55e", background: "#22c55e15",
                  padding: "3px 10px", borderRadius: 20, fontWeight: 500,
                }}>All systems operational</span>
              </div>
              <PipelineFunnel stages={PIPELINE_STAGES} />
            </div>

            {/* Recent Alerts */}
            <div style={{ background: "#111827", borderRadius: 12, padding: 22, border: "1px solid #1e293b" }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 14 }}>Recent Activity</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {ALERTS.slice(0, 3).map((alert, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "8px 0", borderBottom: i < 2 ? "1px solid #1e293b" : "none" }}>
                    <AlertIcon type={alert.type} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12, color: "#cbd5e1", lineHeight: 1.5 }}>{alert.message}</div>
                      <div style={{ fontSize: 10, color: "#475569", marginTop: 3 }}>{alert.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===== EXPERTS TAB ===== */}
        {activeTab === "experts" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontSize: 18, fontWeight: 600 }}>Expert Roster</div>
              <input
                type="text"
                placeholder="Search by name or domain..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                style={{
                  background: "#111827", border: "1px solid #1e293b", borderRadius: 8,
                  padding: "8px 14px", fontSize: 13, color: "#e2e8f0", width: 260,
                  fontFamily: "inherit", outline: "none",
                }}
              />
            </div>

            <div style={{ background: "#111827", borderRadius: 12, border: "1px solid #1e293b", overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #1e293b" }}>
                    {["Status", "Expert", "Domain", "Tasks", "Avg Time", "Accuracy", "Trend"].map((h, i) => (
                      <th key={i} style={{
                        padding: "12px 16px", fontSize: 10, fontWeight: 600, color: "#64748b",
                        textTransform: "uppercase", letterSpacing: "0.08em", textAlign: "left",
                      }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredExperts.map((expert, i) => (
                    <tr key={expert.id}
                      onClick={() => setSelectedExpert(selectedExpert?.id === expert.id ? null : expert)}
                      style={{
                        borderBottom: "1px solid #1e293b11", cursor: "pointer",
                        background: selectedExpert?.id === expert.id ? "#1e293b55" : "transparent",
                        transition: "background 0.15s ease",
                      }}
                    >
                      <td style={{ padding: "12px 16px" }}><StatusDot status={expert.status} /></td>
                      <td style={{ padding: "12px 16px" }}>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{expert.name}</div>
                        <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{expert.university}</div>
                      </td>
                      <td style={{ padding: "12px 16px", fontSize: 12, color: "#94a3b8" }}>{expert.domain}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, fontFamily: "'JetBrains Mono', monospace", fontWeight: 500 }}>
                        {expert.tasksCompleted}
                      </td>
                      <td style={{ padding: "12px 16px", fontSize: 13, fontFamily: "'JetBrains Mono', monospace",
                        color: expert.avgTime <= 25 ? "#22c55e" : "#f59e0b"
                      }}>
                        {expert.avgTime}m
                      </td>
                      <td style={{ padding: "12px 16px", fontSize: 13, fontFamily: "'JetBrains Mono', monospace", fontWeight: 600,
                        color: expert.accuracy >= 96 ? "#22c55e" : expert.accuracy >= 93 ? "#f59e0b" : "#ef4444"
                      }}>
                        {expert.accuracy}%
                      </td>
                      <td style={{ padding: "12px 16px" }}><TrendArrow trend={expert.trend} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Expert Detail Panel */}
            {selectedExpert && (
              <div style={{
                background: "#111827", borderRadius: 12, padding: 24, border: "1px solid #1e293b",
                display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20,
              }}>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>{selectedExpert.name}</div>
                  <div style={{ fontSize: 12, color: "#64748b" }}>{selectedExpert.domain} · {selectedExpert.university}</div>
                  <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>ID: {selectedExpert.id} · Rating: ⭐ {selectedExpert.rating}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.06em" }}>Performance</div>
                  <div style={{ fontSize: 12, color: "#cbd5e1" }}>
                    Accuracy: <strong style={{ color: selectedExpert.accuracy >= 96 ? "#22c55e" : "#f59e0b" }}>{selectedExpert.accuracy}%</strong>
                  </div>
                  <div style={{ fontSize: 12, color: "#cbd5e1" }}>
                    Speed: <strong style={{ color: selectedExpert.avgTime <= 25 ? "#22c55e" : "#f59e0b" }}>{selectedExpert.avgTime} min/task</strong>
                  </div>
                  <div style={{ fontSize: 12, color: "#cbd5e1" }}>
                    Volume: <strong>{selectedExpert.tasksCompleted} tasks</strong>
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.06em" }}>SPL Actions</div>
                  {["Schedule 1:1 Review", "Assign to Priority Queue", "Flag for Bonus Review"].map((action, i) => (
                    <button key={i} style={{
                      padding: "6px 12px", fontSize: 11, fontWeight: 500, border: "1px solid #334155",
                      borderRadius: 6, background: "transparent", color: "#94a3b8", cursor: "pointer",
                      textAlign: "left", fontFamily: "inherit", transition: "all 0.15s ease",
                    }}>{action}</button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== PIPELINE TAB ===== */}
        {activeTab === "pipeline" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
            <div style={{ fontSize: 18, fontWeight: 600 }}>Data Pipeline</div>

            <div style={{ background: "#111827", borderRadius: 12, padding: 24, border: "1px solid #1e293b" }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 20 }}>Task Flow Funnel</div>
              <PipelineFunnel stages={PIPELINE_STAGES} />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12 }}>
              {PIPELINE_STAGES.map((stage, i) => (
                <div key={i} style={{
                  background: "#111827", borderRadius: 12, padding: 18, border: "1px solid #1e293b",
                  textAlign: "center",
                }}>
                  <div style={{ fontSize: 11, color: "#64748b", marginBottom: 8, fontWeight: 500 }}>{stage.name}</div>
                  <div style={{
                    fontSize: 24, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace",
                    color: stage.throughput >= 95 ? "#22c55e" : stage.throughput >= 85 ? "#f59e0b" : "#ef4444",
                  }}>{stage.throughput}%</div>
                  <div style={{ fontSize: 10, color: "#475569", marginTop: 4 }}>throughput</div>
                  <div style={{
                    fontSize: 10, marginTop: 8, padding: "3px 8px", borderRadius: 10,
                    display: "inline-block",
                    background: stage.errors === 0 ? "#22c55e18" : stage.errors > 10 ? "#ef444418" : "#f59e0b18",
                    color: stage.errors === 0 ? "#22c55e" : stage.errors > 10 ? "#ef4444" : "#f59e0b",
                    fontFamily: "'JetBrains Mono', monospace",
                  }}>{stage.errors} errors</div>
                </div>
              ))}
            </div>

            <div style={{ background: "#111827", borderRadius: 12, padding: 22, border: "1px solid #1e293b" }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Pipeline Notes</div>
              <div style={{ fontSize: 12, color: "#94a3b8", lineHeight: 1.7 }}>
                The annotation stage is the current bottleneck at 82.4% throughput — primarily driven by the scope expansion from Lab Alpha (+200 physics tasks). 
                Recommendation: reallocate 2 experts from Linguistics to Physics annotation for the remainder of Sprint 14. 
                Rhea AI QC continues to perform well with only 3 structural errors caught this cycle, all auto-resolved.
              </div>
            </div>
          </div>
        )}

        {/* ===== ALERTS TAB ===== */}
        {activeTab === "alerts" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ fontSize: 18, fontWeight: 600 }}>Activity & Alerts</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {ALERTS.map((alert, i) => (
                <div key={i} style={{
                  background: "#111827", borderRadius: 12, padding: "16px 20px",
                  border: "1px solid #1e293b",
                  display: "flex", alignItems: "flex-start", gap: 14,
                }}>
                  <AlertIcon type={alert.type} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, color: "#e2e8f0", lineHeight: 1.5 }}>{alert.message}</div>
                    <div style={{ fontSize: 11, color: "#475569", marginTop: 4 }}>{alert.time}</div>
                  </div>
                  <button style={{
                    padding: "5px 12px", fontSize: 11, border: "1px solid #334155",
                    borderRadius: 6, background: "transparent", color: "#94a3b8",
                    cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap",
                  }}>Acknowledge</button>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer style={{
        padding: "16px 28px", borderTop: "1px solid #1e293b",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        fontSize: 11, color: "#475569",
      }}>
        <span>micro1 Data Ops Dashboard · Built by Mike K. · Strategic Projects Lead Demo</span>
        <span>Simulated data for demonstration purposes</span>
      </footer>
    </div>
  );
}
