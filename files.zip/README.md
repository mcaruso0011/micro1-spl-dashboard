# micro1 SPL Data Ops Dashboard

A working demo of a **Data Operations Quality Dashboard** — the kind of tool a Strategic Projects Lead at [micro1](https://micro1.ai) would use to manage expert teams, monitor training data quality, and optimize pipeline throughput for AI lab clients.

## Why This Exists

This project was built as a demonstration for the **Strategic Projects Lead** role at micro1. It shows operational thinking about the core SPL responsibilities:

- **Expert Performance Management** — tracking accuracy, velocity, and quality across a team of PhDs/professors
- **Pipeline Health Monitoring** — visualizing task flow from ingestion → annotation → QA → AI QC → delivery
- **Quality Metrics** — surfacing the data integrity signals that matter for frontier model training
- **Alert & Action System** — enabling fast response to bottlenecks and performance issues

## Project Structure

```
micro1-spl-dashboard/
├── README.md              ← You are here
├── CLAUDE_CODE_GUIDE.md   ← How to use Claude Code to build on this
├── dashboard.jsx           ← Main dashboard (React artifact)
├── ROADMAP.md             ← Planned features & enhancements
└── RESEARCH.md            ← micro1 context & role research
```

## Tech Stack

- **React** (single-file artifact, no build step needed)
- **Tailwind-compatible** inline styles (dark theme)
- **Fonts**: DM Sans + JetBrains Mono
- **No external dependencies** beyond React

## Quick Start

This is currently a single-file React component that runs as a Claude artifact. To continue building:

1. Open Claude Code in your terminal
2. Read `CLAUDE_CODE_GUIDE.md` for step-by-step instructions
3. Pick a feature from `ROADMAP.md` and start building

## Key Features

### Overview Tab
- KPI cards: total tasks, average accuracy, task time, active experts
- Daily task volume & quality score charts
- Pipeline funnel visualization
- Recent activity feed

### Expert Roster Tab
- Searchable expert table with status, domain, performance metrics
- Click-to-expand detail panel with SPL action buttons
- Color-coded accuracy and speed thresholds

### Pipeline Tab
- Task flow funnel with throughput percentages
- Stage-by-stage health cards with error counts
- Operational notes with SPL recommendations

### Alerts Tab
- Categorized alerts (warning, info, success)
- Acknowledge actions
- Timestamped activity log

## Author

**Mike K.** — Built as part of exploring the Strategic Projects Lead role at micro1.
